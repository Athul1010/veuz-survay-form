// import logo from './logo.svg';
// import './App.css';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { BrowserRouter, Routes, Route } from "react-router-dom";
// import Home from './Components/Home';
// import DetailsOne from './Components/DetailsOne';
// import TypeList from './Components/TypeList';
// import AllQuestions from './Components/AllQuestions';
// import OnePagePerSection from './Components/OnePagePerSection';
// import OnePagePerQuestion from './Components/OnePagePerQuestion';

// function App() {
//   return (
//     <BrowserRouter>
//       <Routes>
//         <Route path='/' element={<Home/>}/>
//         <Route path="/form/:formId" element={<DetailsOne/>}/>
//         <Route path='/type-text/:formId' element={<TypeList/>} />
//         <Route path="/all-questions/:formId" element={<AllQuestions/>} />
//         <Route path="/one-page-per-section/:formId" element={<OnePagePerSection />} />
//         <Route path="/one-page-per-question/:formId" element={<OnePagePerQuestion />} />
//       </Routes>
//     </BrowserRouter>
//   );
// }

// export default App;


import React, { useState, useEffect } from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Routes, Route, useNavigate } from "react-router-dom";
import Home from './Components/Home';
import DetailsOne from './Components/DetailsOne';
import TypeList from './Components/TypeList';
import AllQuestions from './Components/AllQuestions';
import OnePagePerSection from './Components/OnePagePerSection';
import OnePagePerQuestion from './Components/OnePagePerQuestion';
import Countdown from './Components/Countdown'; // New component for countdown

function App() {
  const [startTimer, setStartTimer] = useState(false); // Condition for timeout to start
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes in seconds
  const navigate = useNavigate(); // Ensure this is defined after component initialization

  useEffect(() => {
    if (startTimer) {
      const timer = setInterval(() => {
        setTimeLeft((prevTime) => {
          if (prevTime <= 1) {
            clearInterval(timer);
            navigate("/"); // Redirect to home when time is over
            return 0;
          }
          return prevTime - 1;
        });
      }, 1000); // Decrease every second

      return () => clearInterval(timer); // Cleanup timer on unmount
    }
  }, [startTimer, navigate]);

  return (
    <BrowserRouter>
      <Countdown timeLeft={timeLeft} /> {/* Show countdown on every page */}
      <Routes>
        <Route path='/' element={<Home setStartTimer={setStartTimer} />} />
        <Route path="/form/:formId" element={<DetailsOne />} />
        <Route path='/type-text/:formId' element={<TypeList />} />
        <Route path="/all-questions/:formId" element={<AllQuestions />} />
        <Route path="/one-page-per-section/:formId" element={<OnePagePerSection />} />
        <Route path="/one-page-per-question/:formId" element={<OnePagePerQuestion />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;




